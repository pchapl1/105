// $('#menu').hide()
// $('p').hide()
// $('.menu-item').hide()



$('#menu').click(function(){
    $('.navegacion').hide()
})