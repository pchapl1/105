// $('#menu').hide()
// $('p').hide()
// $('.menu-item').hide()



// $('#menu').click(function(){
//     $('.navegacion').hide()
// })

$("article:first h2").html("<h1>this is text</h1>")

$("article:first p:last").addClass("test");
$("article:first p:last").removeClass("test");


$(".logo img").on("mouseenter", function(){
    $(this).addClass('challenge')
})

$(".logo img").on("mouseleave", function(){
    $(this).removeClass('challenge')
})